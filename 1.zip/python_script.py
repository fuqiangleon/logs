#!/usr/bin/env python3
#-*- coding:utf-8 -*-

import os
import sys
import subprocess

'''
def exec_commond(command):
	result = os.popen(command)
	res = result.read()
	for line in res.splitlines():
		print(line)
'''

def exec_commond(command):
	p = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
	out, err = p.communicate()
	if out:
		for line in out.splitlines():  
			print(line.decode())
	if err:
		for line in err.splitlines():  
			print(line.decode()) 

def main():
	args = sys.argv
	command = ' '.join(args[1:])
	#print('command:'+command)
	exec_commond(command)

# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
if __name__ == '__main__':
	main()