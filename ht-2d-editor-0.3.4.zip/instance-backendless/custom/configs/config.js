function createColorIcon(color) {
    return {
        width: 20,
        height: 14,
        comps: [
            {
                type: 'rect',
                rect: [0, 0, 20, 14],
                background: color
            }
        ]
    };
};

window.hteditor_config = {
    locale: 'zh',
    libs: [
    	'custom/libs/MockService.js',
        'custom/libs/mockDisplays.js',
        'custom/libs/mockSymbols.js',
        'custom/libs/mockComponents.js',
        'custom/libs/mockAssets.js'
    ],
    serviceClass: 'MockService',
    handleEvent: function(editor, type, params) {
        if ((type === 'request' && params.cmd === 'EXPLORE') ||
            type === 'response' ||
            type === 'fileChanged') {
            return;
        }
        if (params && params.message) {
            console.log('[' + type + ']', params.message);
        }
        else {
            console.log('[' + type + ']');
        }
    },
    valueTypes: {
        Direction: {
            type: 'enum',
            values: ['h', 'v'],
            i18nLabels: ['Horizontal', 'Vertical'],
        },
        Percentage: {
            type: 'number',
            min: 0,
            max: 1,
            step: 0.01
        },
        SwitchState: {
            type: 'enum',
            values: ['on', 'off'],
            i18nLabels: ['SwitchOn', 'SwitchOff'],
        },
        PVState: {
            type: 'enum',
            values: ['#323450', '#454668', '#FF6A01', '#FF2D0D'],
            i18nLabels: ['PV_state_0', 'PV_state_1', 'PV_state_2', 'PV_state_3'],
            icons: [
                createColorIcon('#323450'),
                createColorIcon('#454668'),
                createColorIcon('#FF6A01'),
                createColorIcon('#FF2D0D')
            ]
        },
        PVHLXState: {
            type: 'enum',
            values: ['#6F7082', '#76E33E', '#FF6A01', '#FF2D0D'],
            i18nLabels: ['PV_hlx_state_0', 'PV_hlx_state_1', 'PV_hlx_state_2', 'PV_hlx_state_3'],
            icons: [
                createColorIcon('#6F7082'),
                createColorIcon('#76E33E'),
                createColorIcon('#FF6A01'),
                createColorIcon('#FF2D0D')
            ]
        }
    },
    onEditorCreated: function(editor) {
        var S = hteditor.getString;
        var items = editor.mainMenu.getItems();
        items.push({
            label: S('Help'),
            items: [
                {
                    label: S('Hightopo'),
                    items: [
                        {
                            label: S('Home'),
                            action: function() { window.open('http://www.hightopo.com'); }
                        },
                        {
                            label: S('GetStarted'),
                            action: function() { window.open('http://www.hightopo.com/guide/guide/core/beginners/ht-beginners-guide.html'); }
                        },
                        {
                            label: S('Blog'),
                            action: function() { window.open('http://www.hightopo.com/blog'); }
                        },
                        {
                            label: S('Guide'),
                            action: function() { window.open('http://www.hightopo.com/guide/readme.html'); }
                        }
                    ]
                },
                {
                    label: S('ContactUs'),
                    action: function() { window.open('mailto:service@hightopo.com'); }
                }
            ]
        });
    }
};
