window.htconfig = {
    Default: {
        convertURL: function(url) {
            var mockJSON = (opener && opener.mockJSON) || window.mockJSON;
            if (mockJSON[url]) {
                return { data: mockJSON[url] };
            }
            var mockImage = (opener && opener.mockImage) || window.mockImage;
            if (mockImage[url]) {
                return mockImage[url];
            }
            if (url && !/^data:image/.test(url) && !/^http/.test(url) && !/^https/.test(url)) {
                return 'storage/' + url;
            }
            return url
        }
    }
};