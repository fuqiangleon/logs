window.hteditor_config = {
    locale: 'en'
};

