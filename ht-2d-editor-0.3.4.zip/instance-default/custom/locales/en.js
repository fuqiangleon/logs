hteditor.customStrings = {
     
};

