hteditor.customStrings = { 
    
};

